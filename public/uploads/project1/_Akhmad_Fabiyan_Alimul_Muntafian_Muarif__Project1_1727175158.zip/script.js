document.addEventListener('DOMContentLoaded', () => {
    const cekKodamBtn = document.getElementById('cekKodamBtn');
    const kodamResult = document.getElementById('kodamResult');
    const resultContainer = document.getElementById('result');
    const heading = document.querySelector('header h1');
    let kodamList = [];

    fetch('kodam_list.txt')
        .then(response => response.text())
        .then(data => {
            kodamList = data.split('\n').filter(kodam => kodam.trim() !== '');
        })
        .catch(error => {
            console.error('Error loading Kodam list:', error);
        });

    function getRandomKodam() {
        if (kodamList.length > 0) {
            const randomIndex = Math.floor(Math.random() * kodamList.length);
            return kodamList[randomIndex];
        } else {
            return "Kodam tidak ditemukan.";
        }
    }

    cekKodamBtn.addEventListener('click', () => {
        const nameInput = document.getElementById('nameInput').value.trim();

        if (nameInput) {
            heading.classList.add('shake');
            
            setTimeout(() => {
                heading.classList.remove('shake');
            }, 500);

            resultContainer.classList.add('hidden');
            kodamResult.textContent = '';

            setTimeout(() => {
                const kodam = getRandomKodam();
                kodamResult.textContent = kodam;
                resultContainer.classList.remove('hidden');
            }, 1000);
        } else {
            alert('Silakan masukkan nama Anda.');
        }
    });
});
