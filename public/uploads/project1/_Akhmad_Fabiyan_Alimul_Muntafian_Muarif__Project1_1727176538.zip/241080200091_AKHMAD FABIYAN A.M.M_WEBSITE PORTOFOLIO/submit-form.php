<?php
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$name = sanitize_input($_POST['name']);
$email = sanitize_input($_POST['email']);
$message = sanitize_input($_POST['message']);

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format";
    exit;
}

$to = "akhmadfabiyanmail@gmail.com";
$subject = "Contact Form Submission from $name";
$headers = "From: $email\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

$email_body = "You have received a new message from your website contact form.\n\n";
$email_body .= "Name: $name\n";
$email_body .= "Email: $email\n";
$email_body .= "Message:\n$message\n";

if (mail($to, $subject, $email_body, $headers)) {
    echo "<p>Thank you for contacting us, $name. Your message has been sent successfully!</p>";
} else {
    echo "<p>Sorry, there was an error sending your message. Please try again later.</p>";
}
?>
