const typingElement = document.querySelector('.typing-animation');
const texts = ["Hi I'm Akhmad Fabiyan", "Your web solution partner", "Let's build together"];
const typingSpeed = 100;
const deletingSpeed = 50;
const delayBetweenWords = 2000;

let textIndex = 0;
let charIndex = 0;
let isDeleting = false;

function type() {
    const currentText = texts[textIndex];
    charIndex = isDeleting ? charIndex - 1 : charIndex + 1;
    typingElement.textContent = currentText.slice(0, charIndex);

    if (charIndex === 0) {
        isDeleting = false;
        textIndex = (textIndex + 1) % texts.length;
    } else if (charIndex === currentText.length) {
        isDeleting = true;
        setTimeout(type, delayBetweenWords);
        return;
    }

    setTimeout(type, isDeleting ? deletingSpeed : typingSpeed);
}

const portfolioGrid = document.querySelector('.portfolio-grid');
const portfolioItems = Array.from(portfolioGrid.children);
const seeMoreBtn = document.getElementById('seeMoreBtn');
const seeLessBtn = document.getElementById('seeLessBtn');
const itemsToShow = 4;

function updatePortfolioVisibility() {
    portfolioItems.forEach((item, index) => {
        item.style.display = index < itemsToShow ? 'block' : 'none';
    });

    seeMoreBtn.style.display = portfolioItems.length > itemsToShow ? 'block' : 'none';
}

seeMoreBtn.addEventListener('click', () => {
    portfolioItems.forEach(item => item.style.display = 'block');
    seeMoreBtn.style.display = 'none';
    seeLessBtn.style.display = 'block';
});

seeLessBtn.addEventListener('click', () => {
    updatePortfolioVisibility();
    seeLessBtn.style.display = 'none';
    seeMoreBtn.style.display = 'block';
});

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(type, delayBetweenWords);
    updatePortfolioVisibility();

    const currentYear = new Date().getFullYear();
    document.getElementById('currentYear').textContent = currentYear;

    document.querySelector(".skills-carousel").appendChild(
        document.querySelector(".skills-slide").cloneNode(true)
    );

    const hamburger = document.querySelector('.hamburger-menu');
    const navMenu = document.querySelector('.main-nav ul');
    const navLinks = navMenu.querySelectorAll('li a');

    hamburger.addEventListener('click', () => {
        const isActive = hamburger.classList.toggle('active');
        navMenu.classList.toggle('active', isActive);
    });

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const youtubeLink = document.getElementById('youtube-link');
    const popup = document.getElementById('popup');
    const closePopup = document.getElementById('close-popup');

    youtubeLink.addEventListener('click', (e) => {
        e.preventDefault();
        popup.style.display = 'flex';
    });

    closePopup.addEventListener('click', () => {
        popup.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === popup) {
            popup.style.display = 'none';
        }
    });
});
